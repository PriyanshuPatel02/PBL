package controller;

import dao.DepartmentDAO;
import dao.ProjectDAO;
import model.Department;
import model.Project;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/ProjectServlet")
public class ProjectServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        ProjectDAO projDAO = new ProjectDAO();
        DepartmentDAO deptDAO = new DepartmentDAO();

        List<Department> departments = deptDAO.getAllDepartments();
        request.setAttribute("departments", departments);

        if (action == null || action.equals("list")) {
            List<Project> list = projDAO.getAllProjects();
            request.setAttribute("projectList", list);
            request.getRequestDispatcher("Project.jsp").forward(request, response);

        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Project proj = projDAO.getProjectById(id);
            request.setAttribute("project", proj);
            List<Project> list = projDAO.getAllProjects();
            request.setAttribute("projectList", list);
            request.getRequestDispatcher("Project.jsp").forward(request, response);

        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));
            projDAO.deleteProject(id);
            response.sendRedirect("ProjectServlet?action=list&msg=deleted");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        ProjectDAO dao = new ProjectDAO();

        Project proj = new Project();
        proj.setProjectName(request.getParameter("projectName").trim());
        proj.setStartDate(request.getParameter("startDate"));
        proj.setEndDate(request.getParameter("endDate"));
        proj.setDeptId(Integer.parseInt(request.getParameter("deptId")));
        proj.setStatus(request.getParameter("status"));

        if (action.equals("add")) {
            dao.addProject(proj);
            response.sendRedirect("ProjectServlet?action=list&msg=added");
        } else if (action.equals("update")) {
            int id = Integer.parseInt(request.getParameter("projectId"));
            proj.setProjectId(id);
            dao.updateProject(proj);
            response.sendRedirect("ProjectServlet?action=list&msg=updated");
        }
    }
}
