package controller;

import dao.DepartmentDAO;
import dao.EmployeeDAO;
import model.Department;
import model.Employee;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        EmployeeDAO empDAO = new EmployeeDAO();
        DepartmentDAO deptDAO = new DepartmentDAO();

        List<Department> departments = deptDAO.getAllDepartments();
        request.setAttribute("departments", departments);

        if (action == null || action.equals("list")) {
            List<Employee> list = empDAO.getAllEmployees();
            request.setAttribute("empList", list);
            request.getRequestDispatcher("Employee.jsp").forward(request, response);

        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Employee emp = empDAO.getEmployeeById(id);
            request.setAttribute("employee", emp);
            List<Employee> list = empDAO.getAllEmployees();
            request.setAttribute("empList", list);
            request.getRequestDispatcher("Employee.jsp").forward(request, response);

        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));
            empDAO.deleteEmployee(id);
            response.sendRedirect("EmployeeServlet?action=list&msg=deleted");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        EmployeeDAO dao = new EmployeeDAO();

        Employee emp = new Employee();
        emp.setName(request.getParameter("name").trim());
        emp.setEmail(request.getParameter("email").trim());
        emp.setPhone(request.getParameter("phone").trim());
        emp.setDeptId(Integer.parseInt(request.getParameter("deptId")));
        emp.setRole(request.getParameter("role").trim());
        emp.setSalary(Double.parseDouble(request.getParameter("salary")));

        if (action.equals("add")) {
            dao.addEmployee(emp);
            response.sendRedirect("EmployeeServlet?action=list&msg=added");
        } else if (action.equals("update")) {
            int id = Integer.parseInt(request.getParameter("empId"));
            emp.setEmpId(id);
            dao.updateEmployee(emp);
            response.sendRedirect("EmployeeServlet?action=list&msg=updated");
        }
    }
}
