package controller;

import dao.IndustryDAO;
import model.Industry;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/IndustryServlet")
public class IndustryServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Session check
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        IndustryDAO dao = new IndustryDAO();

        if (action == null || action.equals("list")) {
            List<Industry> list = dao.getAllIndustries();
            request.setAttribute("industryList", list);
            request.getRequestDispatcher("Industry.jsp").forward(request, response);

        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Industry ind = dao.getIndustryById(id);
            request.setAttribute("industry", ind);
            request.getRequestDispatcher("Industry.jsp").forward(request, response);

        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));
            dao.deleteIndustry(id);
            response.sendRedirect("IndustryServlet?action=list&msg=deleted");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        IndustryDAO dao = new IndustryDAO();

        Industry ind = new Industry();
        ind.setIndustryName(request.getParameter("industryName").trim());
        ind.setLocation(request.getParameter("location").trim());
        ind.setType(request.getParameter("type"));

        if (action.equals("add")) {
            dao.addIndustry(ind);
            response.sendRedirect("IndustryServlet?action=list&msg=added");
        } else if (action.equals("update")) {
            int id = Integer.parseInt(request.getParameter("industryId"));
            ind.setIndustryId(id);
            dao.updateIndustry(ind);
            response.sendRedirect("IndustryServlet?action=list&msg=updated");
        }
    }
}
