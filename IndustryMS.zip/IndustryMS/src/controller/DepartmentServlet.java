package controller;

import dao.DepartmentDAO;
import dao.IndustryDAO;
import model.Department;
import model.Industry;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/DepartmentServlet")
public class DepartmentServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        DepartmentDAO deptDAO = new DepartmentDAO();
        IndustryDAO indDAO = new IndustryDAO();

        List<Industry> industries = indDAO.getAllIndustries();
        request.setAttribute("industries", industries);

        if (action == null || action.equals("list")) {
            List<Department> list = deptDAO.getAllDepartments();
            request.setAttribute("deptList", list);
            request.getRequestDispatcher("Department.jsp").forward(request, response);

        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Department dept = deptDAO.getDepartmentById(id);
            request.setAttribute("department", dept);
            List<Department> list = deptDAO.getAllDepartments();
            request.setAttribute("deptList", list);
            request.getRequestDispatcher("Department.jsp").forward(request, response);

        } else if (action.equals("delete")) {
            int id = Integer.parseInt(request.getParameter("id"));
            deptDAO.deleteDepartment(id);
            response.sendRedirect("DepartmentServlet?action=list&msg=deleted");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        DepartmentDAO dao = new DepartmentDAO();

        Department dept = new Department();
        dept.setDeptName(request.getParameter("deptName").trim());
        dept.setIndustryId(Integer.parseInt(request.getParameter("industryId")));
        dept.setManagerName(request.getParameter("managerName").trim());

        if (action.equals("add")) {
            dao.addDepartment(dept);
            response.sendRedirect("DepartmentServlet?action=list&msg=added");
        } else if (action.equals("update")) {
            int id = Integer.parseInt(request.getParameter("deptId"));
            dept.setDeptId(id);
            dao.updateDepartment(dept);
            response.sendRedirect("DepartmentServlet?action=list&msg=updated");
        }
    }
}
