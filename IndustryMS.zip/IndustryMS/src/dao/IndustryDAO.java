package dao;

import model.Industry;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class IndustryDAO {

    public boolean addIndustry(Industry industry) {
        String sql = "INSERT INTO industry (industry_name, location, type) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, industry.getIndustryName());
            ps.setString(2, industry.getLocation());
            ps.setString(3, industry.getType());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Industry> getAllIndustries() {
        List<Industry> list = new ArrayList<>();
        String sql = "SELECT * FROM industry ORDER BY industry_id DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Industry ind = new Industry();
                ind.setIndustryId(rs.getInt("industry_id"));
                ind.setIndustryName(rs.getString("industry_name"));
                ind.setLocation(rs.getString("location"));
                ind.setType(rs.getString("type"));
                list.add(ind);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Industry getIndustryById(int id) {
        String sql = "SELECT * FROM industry WHERE industry_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Industry ind = new Industry();
                ind.setIndustryId(rs.getInt("industry_id"));
                ind.setIndustryName(rs.getString("industry_name"));
                ind.setLocation(rs.getString("location"));
                ind.setType(rs.getString("type"));
                return ind;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateIndustry(Industry industry) {
        String sql = "UPDATE industry SET industry_name=?, location=?, type=? WHERE industry_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, industry.getIndustryName());
            ps.setString(2, industry.getLocation());
            ps.setString(3, industry.getType());
            ps.setInt(4, industry.getIndustryId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteIndustry(int id) {
        String sql = "DELETE FROM industry WHERE industry_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
