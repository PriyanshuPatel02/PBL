package dao;

import model.Project;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjectDAO {

    public boolean addProject(Project proj) {
        String sql = "INSERT INTO project (project_name, start_date, end_date, dept_id, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, proj.getProjectName());
            ps.setString(2, proj.getStartDate());
            ps.setString(3, proj.getEndDate());
            ps.setInt(4, proj.getDeptId());
            ps.setString(5, proj.getStatus());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Project> getAllProjects() {
        List<Project> list = new ArrayList<>();
        String sql = "SELECT p.*, d.dept_name FROM project p JOIN department d ON p.dept_id=d.dept_id ORDER BY p.project_id DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Project proj = new Project();
                proj.setProjectId(rs.getInt("project_id"));
                proj.setProjectName(rs.getString("project_name"));
                proj.setStartDate(rs.getString("start_date"));
                proj.setEndDate(rs.getString("end_date"));
                proj.setDeptId(rs.getInt("dept_id"));
                proj.setDeptName(rs.getString("dept_name"));
                proj.setStatus(rs.getString("status"));
                list.add(proj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Project getProjectById(int id) {
        String sql = "SELECT p.*, d.dept_name FROM project p JOIN department d ON p.dept_id=d.dept_id WHERE p.project_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Project proj = new Project();
                proj.setProjectId(rs.getInt("project_id"));
                proj.setProjectName(rs.getString("project_name"));
                proj.setStartDate(rs.getString("start_date"));
                proj.setEndDate(rs.getString("end_date"));
                proj.setDeptId(rs.getInt("dept_id"));
                proj.setDeptName(rs.getString("dept_name"));
                proj.setStatus(rs.getString("status"));
                return proj;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateProject(Project proj) {
        String sql = "UPDATE project SET project_name=?, start_date=?, end_date=?, dept_id=?, status=? WHERE project_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, proj.getProjectName());
            ps.setString(2, proj.getStartDate());
            ps.setString(3, proj.getEndDate());
            ps.setInt(4, proj.getDeptId());
            ps.setString(5, proj.getStatus());
            ps.setInt(6, proj.getProjectId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteProject(int id) {
        String sql = "DELETE FROM project WHERE project_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
