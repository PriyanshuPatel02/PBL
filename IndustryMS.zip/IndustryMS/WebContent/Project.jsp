<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, model.Project, model.Department" %>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("loggedUser") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    List<Project> projectList = (List<Project>) request.getAttribute("projectList");
    Project editProj = (Project) request.getAttribute("project");
    List<Department> departments = (List<Department>) request.getAttribute("departments");
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Project Management</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="layout">
    <%@ include file="sidebar.jsp" %>
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Project Management</h1>
                <div class="breadcrumb">Dashboard / Projects</div>
            </div>
        </div>
        <div class="page-content">

            <% if ("added".equals(msg)) { %><div class="alert alert-success">✅ Project added successfully!</div><% } %>
            <% if ("updated".equals(msg)) { %><div class="alert alert-success">✅ Project updated successfully!</div><% } %>
            <% if ("deleted".equals(msg)) { %><div class="alert alert-success">✅ Project deleted successfully!</div><% } %>

            <!-- Add / Edit Form -->
            <div class="card">
                <div class="card-header">
                    <h3><%= editProj != null ? "✏️ Edit Project" : "➕ Add New Project" %></h3>
                    <% if (editProj != null) { %>
                        <a href="ProjectServlet?action=list" class="btn btn-sm btn-outline">Cancel</a>
                    <% } %>
                </div>
                <div class="card-body">
                    <form action="ProjectServlet" method="post">
                        <input type="hidden" name="action" value="<%= editProj != null ? "update" : "add" %>">
                        <% if (editProj != null) { %>
                            <input type="hidden" name="projectId" value="<%= editProj.getProjectId() %>">
                        <% } %>

                        <div class="form-grid">
                            <div class="form-group">
                                <label>Project Name *</label>
                                <input type="text" name="projectName"
                                    value="<%= editProj != null ? editProj.getProjectName() : "" %>"
                                    placeholder="e.g. ERP System Development" required>
                            </div>
                            <div class="form-group">
                                <label>Assigned Department *</label>
                                <select name="deptId" required>
                                    <option value="">-- Select Department --</option>
                                    <% if (departments != null) { for (Department dept : departments) { %>
                                        <option value="<%= dept.getDeptId() %>"
                                            <%= editProj != null && editProj.getDeptId() == dept.getDeptId() ? "selected" : "" %>>
                                            <%= dept.getDeptName() %>
                                        </option>
                                    <% } } %>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Start Date *</label>
                                <input type="date" name="startDate"
                                    value="<%= editProj != null ? editProj.getStartDate() : "" %>" required>
                            </div>
                            <div class="form-group">
                                <label>End Date *</label>
                                <input type="date" name="endDate"
                                    value="<%= editProj != null ? editProj.getEndDate() : "" %>" required>
                            </div>
                        </div>

                        <div class="form-group" style="max-width:250px;">
                            <label>Status *</label>
                            <select name="status" required>
                                <option value="Active" <%= editProj != null && "Active".equals(editProj.getStatus()) ? "selected" : "" %>>Active</option>
                                <option value="Completed" <%= editProj != null && "Completed".equals(editProj.getStatus()) ? "selected" : "" %>>Completed</option>
                                <option value="On Hold" <%= editProj != null && "On Hold".equals(editProj.getStatus()) ? "selected" : "" %>>On Hold</option>
                            </select>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">
                                <%= editProj != null ? "💾 Update Project" : "➕ Add Project" %>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Project List -->
            <div class="card">
                <div class="card-header">
                    <h3>📋 Project List</h3>
                    <span style="font-size:13px; color:var(--text-light);"><%= projectList != null ? projectList.size() : 0 %> records</span>
                </div>
                <div class="table-responsive">
                    <% if (projectList == null || projectList.isEmpty()) { %>
                        <div class="empty-state">
                            <div class="empty-icon">📁</div>
                            <p>No projects found. Add one above!</p>
                        </div>
                    <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Project Name</th>
                                <th>Department</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% int sno = 1; for (Project proj : projectList) { %>
                            <tr>
                                <td><%= sno++ %></td>
                                <td><strong><%= proj.getProjectName() %></strong></td>
                                <td>🏢 <%= proj.getDeptName() %></td>
                                <td><%= proj.getStartDate() %></td>
                                <td><%= proj.getEndDate() %></td>
                                <td>
                                    <span class="badge <%=
                                        "Active".equals(proj.getStatus()) ? "badge-active" :
                                        "Completed".equals(proj.getStatus()) ? "badge-completed" : "badge-hold"
                                    %>">
                                        <%= proj.getStatus() %>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-btns">
                                        <a href="ProjectServlet?action=edit&id=<%= proj.getProjectId() %>" class="btn btn-sm btn-warning">✏️ Edit</a>
                                        <a href="ProjectServlet?action=delete&id=<%= proj.getProjectId() %>" class="btn btn-sm btn-danger"
                                           onclick="return confirm('Delete this project?')">🗑️ Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                    <% } %>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
</html>
