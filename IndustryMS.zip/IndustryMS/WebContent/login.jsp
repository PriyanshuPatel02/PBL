<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Industry Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-logo">
            <div class="logo-icon">🏭</div>
            <h1>Industry Management System</h1>
        </div>

        <h2>Welcome Back</h2>
        <p class="subtitle">Sign in to your account to continue</p>

        <% String error = (String) request.getAttribute("error"); %>
        <% String success = (String) request.getAttribute("success"); %>
        <% if (error != null) { %>
            <div class="alert alert-danger">⚠️ <%= error %></div>
        <% } %>
        <% if (success != null) { %>
            <div class="alert alert-success">✅ <%= success %></div>
        <% } %>

        <div class="alert alert-info" style="font-size:12px;">
            🔑 Default Admin: <strong>admin@company.com</strong> / <strong>admin123</strong>
        </div>

        <form action="LoginServlet" method="post">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn btn-primary">Sign In →</button>
        </form>

        <p class="auth-link">Don't have an account? <a href="register.jsp">Register here</a></p>
    </div>
</div>
</body>
</html>
