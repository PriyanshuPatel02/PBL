<%@ page import="model.User" %>
<%
    HttpSession sidebarSess = request.getSession(false);
    User sidebarUser = (sidebarSess != null) ? (User) sidebarSess.getAttribute("loggedUser") : null;
    String currentURI = request.getRequestURI();
    String currentPage = currentURI.substring(currentURI.lastIndexOf("/") + 1);
    String currentServlet = request.getServletPath();
%>
<div class="sidebar">
    <div class="sidebar-brand">
        <div class="brand-icon">🏭</div>
        <h2>Industry Management System</h2>
        <p>JSP + Servlet + MySQL</p>
    </div>

    <% if (sidebarUser != null) { %>
    <div class="sidebar-user">
        <div class="user-name"><%= sidebarUser.getName() %></div>
        <div class="user-role"><%= sidebarUser.getEmail() %></div>
        <span class="user-badge"><%= sidebarUser.getRole() %></span>
    </div>
    <% } %>

    <nav class="sidebar-nav">
        <div class="nav-label">Main</div>
        <a href="dashboard.jsp" class="nav-item <%= currentPage.equals("dashboard.jsp") ? "active" : "" %>">
            <span class="icon">📊</span> Dashboard
        </a>

        <div class="nav-label">Management</div>
        <a href="IndustryServlet?action=list" class="nav-item <%= currentServlet.contains("IndustryServlet") || currentPage.contains("Industry") ? "active" : "" %>">
            <span class="icon">🏭</span> Industries
        </a>
        <a href="DepartmentServlet?action=list" class="nav-item <%= currentServlet.contains("DepartmentServlet") || currentPage.contains("Department") ? "active" : "" %>">
            <span class="icon">🏢</span> Departments
        </a>
        <a href="EmployeeServlet?action=list" class="nav-item <%= currentServlet.contains("EmployeeServlet") || currentPage.contains("Employee") ? "active" : "" %>">
            <span class="icon">👥</span> Employees
        </a>
        <a href="ProjectServlet?action=list" class="nav-item <%= currentServlet.contains("ProjectServlet") || currentPage.contains("Project") ? "active" : "" %>">
            <span class="icon">📁</span> Projects
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="LogoutServlet" class="nav-item" style="color:rgba(255,255,255,0.6);" onclick="return confirm('Are you sure you want to logout?')">
            <span class="icon">🚪</span> Logout
        </a>
    </div>
</div>
