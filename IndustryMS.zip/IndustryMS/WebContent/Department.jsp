<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, model.Department, model.Industry" %>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("loggedUser") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    List<Department> deptList = (List<Department>) request.getAttribute("deptList");
    Department editDept = (Department) request.getAttribute("department");
    List<Industry> industries = (List<Industry>) request.getAttribute("industries");
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Department Management</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="layout">
    <%@ include file="sidebar.jsp" %>
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Department Management</h1>
                <div class="breadcrumb">Dashboard / Departments</div>
            </div>
        </div>
        <div class="page-content">

            <% if ("added".equals(msg)) { %><div class="alert alert-success">✅ Department added successfully!</div><% } %>
            <% if ("updated".equals(msg)) { %><div class="alert alert-success">✅ Department updated successfully!</div><% } %>
            <% if ("deleted".equals(msg)) { %><div class="alert alert-success">✅ Department deleted successfully!</div><% } %>

            <!-- Add / Edit Form -->
            <div class="card">
                <div class="card-header">
                    <h3><%= editDept != null ? "✏️ Edit Department" : "➕ Add New Department" %></h3>
                    <% if (editDept != null) { %>
                        <a href="DepartmentServlet?action=list" class="btn btn-sm btn-outline">Cancel</a>
                    <% } %>
                </div>
                <div class="card-body">
                    <form action="DepartmentServlet" method="post">
                        <input type="hidden" name="action" value="<%= editDept != null ? "update" : "add" %>">
                        <% if (editDept != null) { %>
                            <input type="hidden" name="deptId" value="<%= editDept.getDeptId() %>">
                        <% } %>

                        <div class="form-grid">
                            <div class="form-group">
                                <label>Department Name *</label>
                                <input type="text" name="deptName"
                                    value="<%= editDept != null ? editDept.getDeptName() : "" %>"
                                    placeholder="e.g. Software Development" required>
                            </div>
                            <div class="form-group">
                                <label>Manager Name *</label>
                                <input type="text" name="managerName"
                                    value="<%= editDept != null ? editDept.getManagerName() : "" %>"
                                    placeholder="e.g. Ravi Kumar" required>
                            </div>
                        </div>

                        <div class="form-group" style="max-width:400px;">
                            <label>Assigned Industry *</label>
                            <select name="industryId" required>
                                <option value="">-- Select Industry --</option>
                                <% if (industries != null) { for (Industry ind : industries) { %>
                                    <option value="<%= ind.getIndustryId() %>"
                                        <%= editDept != null && editDept.getIndustryId() == ind.getIndustryId() ? "selected" : "" %>>
                                        <%= ind.getIndustryName() %> (<%= ind.getType() %>)
                                    </option>
                                <% } } %>
                            </select>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">
                                <%= editDept != null ? "💾 Update Department" : "➕ Add Department" %>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Department List -->
            <div class="card">
                <div class="card-header">
                    <h3>📋 Department List</h3>
                    <span style="font-size:13px; color:var(--text-light);"><%= deptList != null ? deptList.size() : 0 %> records</span>
                </div>
                <div class="table-responsive">
                    <% if (deptList == null || deptList.isEmpty()) { %>
                        <div class="empty-state">
                            <div class="empty-icon">🏢</div>
                            <p>No departments found. Add one above!</p>
                        </div>
                    <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Department Name</th>
                                <th>Industry</th>
                                <th>Manager</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% int sno = 1; for (Department dept : deptList) { %>
                            <tr>
                                <td><%= sno++ %></td>
                                <td><strong><%= dept.getDeptName() %></strong></td>
                                <td>🏭 <%= dept.getIndustryName() %></td>
                                <td>👤 <%= dept.getManagerName() %></td>
                                <td>
                                    <div class="action-btns">
                                        <a href="DepartmentServlet?action=edit&id=<%= dept.getDeptId() %>" class="btn btn-sm btn-warning">✏️ Edit</a>
                                        <a href="DepartmentServlet?action=delete&id=<%= dept.getDeptId() %>" class="btn btn-sm btn-danger"
                                           onclick="return confirm('Delete this department?')">🗑️ Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                    <% } %>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
</html>
