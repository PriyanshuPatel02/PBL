<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="model.User, dao.IndustryDAO, dao.DepartmentDAO, dao.EmployeeDAO, dao.ProjectDAO" %>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("loggedUser") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    User loggedUser = (User) sess.getAttribute("loggedUser");
    int indCount = new IndustryDAO().getAllIndustries().size();
    int deptCount = new DepartmentDAO().getAllDepartments().size();
    int empCount = new EmployeeDAO().getAllEmployees().size();
    int projCount = new ProjectDAO().getAllProjects().size();
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Industry Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="layout">
    <%@ include file="sidebar.jsp" %>
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Dashboard</h1>
                <div class="breadcrumb">Home / Dashboard</div>
            </div>
            <div style="font-size:13px; color:var(--text-light);">
                📅 <%= new java.util.Date().toString().substring(0,10) %>
            </div>
        </div>
        <div class="page-content">

            <div style="margin-bottom:24px;">
                <h2 style="font-size:20px; font-weight:700;">👋 Welcome, <%= loggedUser.getName() %>!</h2>
                <p style="color:var(--text-light); margin-top:4px; font-size:14px;">
                    Here's an overview of your Industry Management System.
                </p>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">🏭</div>
                    <div class="stat-info">
                        <h3><%= indCount %></h3>
                        <p>Total Industries</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon green">🏢</div>
                    <div class="stat-info">
                        <h3><%= deptCount %></h3>
                        <p>Departments</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon orange">👥</div>
                    <div class="stat-info">
                        <h3><%= empCount %></h3>
                        <p>Employees</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon purple">📁</div>
                    <div class="stat-info">
                        <h3><%= projCount %></h3>
                        <p>Projects</p>
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                <div class="card">
                    <div class="card-header"><h3>Quick Navigation</h3></div>
                    <div class="card-body">
                        <div style="display:flex; flex-direction:column; gap:10px;">
                            <a href="IndustryServlet?action=list" class="btn btn-outline" style="justify-content:flex-start;">
                                🏭 Manage Industries
                            </a>
                            <a href="DepartmentServlet?action=list" class="btn btn-outline" style="justify-content:flex-start;">
                                🏢 Manage Departments
                            </a>
                            <a href="EmployeeServlet?action=list" class="btn btn-outline" style="justify-content:flex-start;">
                                👥 Manage Employees
                            </a>
                            <a href="ProjectServlet?action=list" class="btn btn-outline" style="justify-content:flex-start;">
                                📁 Manage Projects
                            </a>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h3>Your Profile</h3></div>
                    <div class="card-body">
                        <table style="font-size:14px;">
                            <tr>
                                <td style="padding:8px 4px; color:var(--text-light); font-weight:600;">Name</td>
                                <td style="padding:8px 12px;"><%= loggedUser.getName() %></td>
                            </tr>
                            <tr>
                                <td style="padding:8px 4px; color:var(--text-light); font-weight:600;">Email</td>
                                <td style="padding:8px 12px;"><%= loggedUser.getEmail() %></td>
                            </tr>
                            <tr>
                                <td style="padding:8px 4px; color:var(--text-light); font-weight:600;">Phone</td>
                                <td style="padding:8px 12px;"><%= loggedUser.getPhone() %></td>
                            </tr>
                            <tr>
                                <td style="padding:8px 4px; color:var(--text-light); font-weight:600;">Role</td>
                                <td style="padding:8px 12px;">
                                    <span class="badge <%= loggedUser.getRole().equals("Admin") ? "badge-admin" : "badge-emp" %>">
                                        <%= loggedUser.getRole() %>
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
</html>
