<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, model.Industry" %>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("loggedUser") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    List<Industry> industryList = (List<Industry>) request.getAttribute("industryList");
    Industry editIndustry = (Industry) request.getAttribute("industry");
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Industry Management</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="layout">
    <%@ include file="sidebar.jsp" %>
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Industry Management</h1>
                <div class="breadcrumb">Dashboard / Industries</div>
            </div>
        </div>
        <div class="page-content">

            <% if ("added".equals(msg)) { %><div class="alert alert-success">✅ Industry added successfully!</div><% } %>
            <% if ("updated".equals(msg)) { %><div class="alert alert-success">✅ Industry updated successfully!</div><% } %>
            <% if ("deleted".equals(msg)) { %><div class="alert alert-success">✅ Industry deleted successfully!</div><% } %>

            <!-- Add / Edit Form -->
            <div class="card">
                <div class="card-header">
                    <h3><%= editIndustry != null ? "✏️ Edit Industry" : "➕ Add New Industry" %></h3>
                    <% if (editIndustry != null) { %>
                        <a href="IndustryServlet?action=list" class="btn btn-sm btn-outline">Cancel</a>
                    <% } %>
                </div>
                <div class="card-body">
                    <form action="IndustryServlet" method="post">
                        <input type="hidden" name="action" value="<%= editIndustry != null ? "update" : "add" %>">
                        <% if (editIndustry != null) { %>
                            <input type="hidden" name="industryId" value="<%= editIndustry.getIndustryId() %>">
                        <% } %>

                        <div class="form-grid">
                            <div class="form-group">
                                <label>Industry Name *</label>
                                <input type="text" name="industryName"
                                    value="<%= editIndustry != null ? editIndustry.getIndustryName() : "" %>"
                                    placeholder="e.g. TechCorp Solutions" required>
                            </div>
                            <div class="form-group">
                                <label>Location *</label>
                                <input type="text" name="location"
                                    value="<%= editIndustry != null ? editIndustry.getLocation() : "" %>"
                                    placeholder="e.g. Mumbai" required>
                            </div>
                        </div>

                        <div class="form-group" style="max-width:300px;">
                            <label>Industry Type *</label>
                            <select name="type" required>
                                <option value="">-- Select Type --</option>
                                <option value="Manufacturing" <%= editIndustry != null && "Manufacturing".equals(editIndustry.getType()) ? "selected" : "" %>>Manufacturing</option>
                                <option value="IT" <%= editIndustry != null && "IT".equals(editIndustry.getType()) ? "selected" : "" %>>IT</option>
                                <option value="Service" <%= editIndustry != null && "Service".equals(editIndustry.getType()) ? "selected" : "" %>>Service</option>
                            </select>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">
                                <%= editIndustry != null ? "💾 Update Industry" : "➕ Add Industry" %>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Industry List -->
            <div class="card">
                <div class="card-header">
                    <h3>📋 Industry List</h3>
                    <span style="font-size:13px; color:var(--text-light);"><%= industryList != null ? industryList.size() : 0 %> records</span>
                </div>
                <div class="table-responsive">
                    <% if (industryList == null || industryList.isEmpty()) { %>
                        <div class="empty-state">
                            <div class="empty-icon">🏭</div>
                            <p>No industries found. Add one above!</p>
                        </div>
                    <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Industry Name</th>
                                <th>Location</th>
                                <th>Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% int sno = 1; for (Industry ind : industryList) { %>
                            <tr>
                                <td><%= sno++ %></td>
                                <td><strong><%= ind.getIndustryName() %></strong></td>
                                <td>📍 <%= ind.getLocation() %></td>
                                <td>
                                    <span class="badge <%= "IT".equals(ind.getType()) ? "badge-it" : "Manufacturing".equals(ind.getType()) ? "badge-mfg" : "badge-svc" %>">
                                        <%= ind.getType() %>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-btns">
                                        <a href="IndustryServlet?action=edit&id=<%= ind.getIndustryId() %>" class="btn btn-sm btn-warning">✏️ Edit</a>
                                        <a href="IndustryServlet?action=delete&id=<%= ind.getIndustryId() %>" class="btn btn-sm btn-danger"
                                           onclick="return confirm('Delete this industry? All linked departments will also be removed.')">🗑️ Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                    <% } %>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
</html>
