<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, model.Employee, model.Department" %>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("loggedUser") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    List<Employee> empList = (List<Employee>) request.getAttribute("empList");
    Employee editEmp = (Employee) request.getAttribute("employee");
    List<Department> departments = (List<Department>) request.getAttribute("departments");
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Management</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="layout">
    <%@ include file="sidebar.jsp" %>
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Employee Management</h1>
                <div class="breadcrumb">Dashboard / Employees</div>
            </div>
        </div>
        <div class="page-content">

            <% if ("added".equals(msg)) { %><div class="alert alert-success">✅ Employee added successfully!</div><% } %>
            <% if ("updated".equals(msg)) { %><div class="alert alert-success">✅ Employee updated successfully!</div><% } %>
            <% if ("deleted".equals(msg)) { %><div class="alert alert-success">✅ Employee deleted successfully!</div><% } %>

            <!-- Add / Edit Form -->
            <div class="card">
                <div class="card-header">
                    <h3><%= editEmp != null ? "✏️ Edit Employee" : "➕ Add New Employee" %></h3>
                    <% if (editEmp != null) { %>
                        <a href="EmployeeServlet?action=list" class="btn btn-sm btn-outline">Cancel</a>
                    <% } %>
                </div>
                <div class="card-body">
                    <form action="EmployeeServlet" method="post">
                        <input type="hidden" name="action" value="<%= editEmp != null ? "update" : "add" %>">
                        <% if (editEmp != null) { %>
                            <input type="hidden" name="empId" value="<%= editEmp.getEmpId() %>">
                        <% } %>

                        <div class="form-grid">
                            <div class="form-group">
                                <label>Full Name *</label>
                                <input type="text" name="name"
                                    value="<%= editEmp != null ? editEmp.getName() : "" %>"
                                    placeholder="e.g. Priya Sharma" required>
                            </div>
                            <div class="form-group">
                                <label>Email *</label>
                                <input type="email" name="email"
                                    value="<%= editEmp != null ? editEmp.getEmail() : "" %>"
                                    placeholder="priya@company.com" required>
                            </div>
                            <div class="form-group">
                                <label>Phone *</label>
                                <input type="tel" name="phone"
                                    value="<%= editEmp != null ? editEmp.getPhone() : "" %>"
                                    placeholder="9876543210" required>
                            </div>
                            <div class="form-group">
                                <label>Role / Designation *</label>
                                <input type="text" name="role"
                                    value="<%= editEmp != null ? editEmp.getRole() : "" %>"
                                    placeholder="e.g. Software Engineer" required>
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label>Department *</label>
                                <select name="deptId" required>
                                    <option value="">-- Select Department --</option>
                                    <% if (departments != null) { for (Department dept : departments) { %>
                                        <option value="<%= dept.getDeptId() %>"
                                            <%= editEmp != null && editEmp.getDeptId() == dept.getDeptId() ? "selected" : "" %>>
                                            <%= dept.getDeptName() %>
                                        </option>
                                    <% } } %>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Salary (₹) *</label>
                                <input type="number" name="salary" step="0.01" min="0"
                                    value="<%= editEmp != null ? editEmp.getSalary() : "" %>"
                                    placeholder="50000" required>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">
                                <%= editEmp != null ? "💾 Update Employee" : "➕ Add Employee" %>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Employee List -->
            <div class="card">
                <div class="card-header">
                    <h3>📋 Employee List</h3>
                    <span style="font-size:13px; color:var(--text-light);"><%= empList != null ? empList.size() : 0 %> records</span>
                </div>
                <div class="table-responsive">
                    <% if (empList == null || empList.isEmpty()) { %>
                        <div class="empty-state">
                            <div class="empty-icon">👥</div>
                            <p>No employees found. Add one above!</p>
                        </div>
                    <% } else { %>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Department</th>
                                <th>Role</th>
                                <th>Salary</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% int sno = 1; for (Employee emp : empList) { %>
                            <tr>
                                <td><%= sno++ %></td>
                                <td><strong><%= emp.getName() %></strong></td>
                                <td><%= emp.getEmail() %></td>
                                <td><%= emp.getPhone() %></td>
                                <td>🏢 <%= emp.getDeptName() %></td>
                                <td><%= emp.getRole() %></td>
                                <td>₹<%= String.format("%.0f", emp.getSalary()) %></td>
                                <td>
                                    <div class="action-btns">
                                        <a href="EmployeeServlet?action=edit&id=<%= emp.getEmpId() %>" class="btn btn-sm btn-warning">✏️ Edit</a>
                                        <a href="EmployeeServlet?action=delete&id=<%= emp.getEmpId() %>" class="btn btn-sm btn-danger"
                                           onclick="return confirm('Delete this employee?')">🗑️ Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                    <% } %>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
</html>
