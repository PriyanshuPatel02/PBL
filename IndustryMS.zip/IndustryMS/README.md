# Industry Management System
## JSP + Servlet + MySQL | MVC Architecture

---

## 📁 Project Structure

```
IndustryMS/
├── WebContent/
│   ├── css/
│   │   └── style.css              ← Stylesheet
│   ├── WEB-INF/
│   │   └── web.xml                ← Deployment descriptor
│   ├── login.jsp                  ← Login page (5.1)
│   ├── register.jsp               ← Registration page (5.1)
│   ├── dashboard.jsp              ← Dashboard with stats (5.2)
│   ├── sidebar.jsp                ← Reusable sidebar
│   ├── Industry.jsp               ← Industry CRUD (5.3)
│   ├── Department.jsp             ← Department CRUD (5.4)
│   ├── Employee.jsp               ← Employee CRUD (5.5)
│   └── Project.jsp                ← Project CRUD (5.6)
│
└── src/
    ├── util/
    │   └── DBConnection.java      ← MySQL connection
    ├── model/
    │   ├── User.java
    │   ├── Industry.java
    │   ├── Department.java
    │   ├── Employee.java
    │   └── Project.java
    ├── dao/
    │   ├── UserDAO.java
    │   ├── IndustryDAO.java
    │   ├── DepartmentDAO.java
    │   ├── EmployeeDAO.java
    │   └── ProjectDAO.java
    └── controller/
        ├── RegisterServlet.java
        ├── LoginServlet.java
        ├── LogoutServlet.java
        ├── IndustryServlet.java
        ├── DepartmentServlet.java
        ├── EmployeeServlet.java
        └── ProjectServlet.java
```

---

## ⚙️ Setup Steps

### Step 1: MySQL Database
1. Open MySQL Workbench or command line
2. Run `database.sql` to create all tables
3. Default admin: `admin@company.com` / `admin123`

### Step 2: Configure DB Connection
Edit `src/util/DBConnection.java`:
```java
private static final String URL = "jdbc:mysql://localhost:3306/industry_management";
private static final String USER = "root";
private static final String PASSWORD = "YOUR_MYSQL_PASSWORD"; // ← Change this
```

### Step 3: Eclipse/IntelliJ Setup
1. Create **Dynamic Web Project** named `IndustryMS`
2. Copy all source files to their respective locations
3. Add **MySQL Connector/J** JAR to `WEB-INF/lib/`
   - Download from: https://dev.mysql.com/downloads/connector/j/
4. Configure **Apache Tomcat** server (v9 or 10)
5. Deploy and run

### Step 4: Access
- URL: `http://localhost:8080/IndustryMS/`
- Default redirects to `login.jsp`

---

## 🔐 User Roles
| Role | Access |
|------|--------|
| **Admin** | Full CRUD on all modules |
| **Employee** | View/limited access |

---

## 🗄️ Database Tables
| Table | Primary Key | Foreign Keys |
|-------|------------|--------------|
| users | user_id | — |
| industry | industry_id | — |
| department | dept_id | industry_id → industry |
| employee | emp_id | dept_id → department |
| project | project_id | dept_id → department |

---

## 📦 Dependencies
- **JDK** 11+ 
- **Apache Tomcat** 9.x or 10.x
- **MySQL** 8.x
- **MySQL Connector/J** 8.x JAR
- **javax.servlet-api** (provided by Tomcat)

---

## 🔗 Navigation Flow
```
Login/Register → Dashboard
                    ↓
         Industry / Department / Employee / Project
                    ↓
           Perform CRUD Operations
                    ↓
         Return to Dashboard / Logout
```
