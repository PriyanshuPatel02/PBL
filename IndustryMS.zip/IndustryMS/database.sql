-- Industry Management System - Database Setup
-- Run this script in MySQL to create the database and tables

CREATE DATABASE IF NOT EXISTS industry_management;
USE industry_management;

-- User Table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Employee') NOT NULL DEFAULT 'Employee',
    phone VARCHAR(15) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Industry Table
CREATE TABLE IF NOT EXISTS industry (
    industry_id INT AUTO_INCREMENT PRIMARY KEY,
    industry_name VARCHAR(150) NOT NULL,
    location VARCHAR(150) NOT NULL,
    type ENUM('Manufacturing', 'IT', 'Service') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Department Table
CREATE TABLE IF NOT EXISTS department (
    dept_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(150) NOT NULL,
    industry_id INT NOT NULL,
    manager_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (industry_id) REFERENCES industry(industry_id) ON DELETE CASCADE
);

-- Employee Table
CREATE TABLE IF NOT EXISTS employee (
    emp_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    dept_id INT NOT NULL,
    role VARCHAR(100) NOT NULL,
    salary DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id) ON DELETE CASCADE
);

-- Project Table
CREATE TABLE IF NOT EXISTS project (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    project_name VARCHAR(150) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    dept_id INT NOT NULL,
    status ENUM('Active', 'Completed', 'On Hold') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id) ON DELETE CASCADE
);

-- Insert default admin user (password: admin123)
INSERT INTO users (name, email, password, role, phone) VALUES
('Administrator', 'admin@company.com', MD5('admin123'), 'Admin', '9999999999')
ON DUPLICATE KEY UPDATE name=name;

-- Sample data
INSERT INTO industry (industry_name, location, type) VALUES
('TechCorp Solutions', 'Mumbai', 'IT'),
('AutoMake Ltd', 'Pune', 'Manufacturing'),
('ServiceFirst Inc', 'Bangalore', 'Service')
ON DUPLICATE KEY UPDATE industry_name=industry_name;

INSERT INTO department (dept_name, industry_id, manager_name) VALUES
('Software Development', 1, 'Ravi Kumar'),
('QA & Testing', 1, 'Priya Sharma'),
('Production Line A', 2, 'Amit Patel'),
('Customer Support', 3, 'Neha Singh')
ON DUPLICATE KEY UPDATE dept_name=dept_name;
